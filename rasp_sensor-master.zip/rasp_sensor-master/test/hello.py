import time

for i in range(1, 100):
	print('hello')
	time.sleep(1)
