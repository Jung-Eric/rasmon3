import hello
import time

time.sleep(0.5)

for i in range(1, 100):
	print('baby')


